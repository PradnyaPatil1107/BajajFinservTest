package com.app.entities;

public class Prngenerate {

	public static void main(String[] args) {
		
	
		
		        if (args.length != 2) {
		            System.out.println("Usage: java -jar <jar-file> <PRN> <path-to-json>");
		            return;
		        }

		        String prnNumber = args[0].toLowerCase();
		        String jsonFilePath = args[1];

		        try {
		            // Step 2: Load and Parse JSON
		            String destinationValue = Utils_json.findDestination(jsonFilePath);

		            // Step 3: Generate Random String
		            String randomString =Utils_hash.generateRandomString();

		            // Step 4: Generate MD5 Hash
		            String md5Hash = Utils_hash.generateMD5Hash(prnNumber, destinationValue, randomString);

		            // Step 5: Output the Result
		            String output = md5Hash + ";" + randomString;
		            System.out.println(output);
		        } catch (Exception e) {
		            e.printStackTrace();
		        }
		    }
		

	}


