package com.app.entities;



import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;

import java.io.FileReader;
import java.io.IOException;


import java.io.IOException;


public class Utils_json {
	
	 public static String findDestination(String jsonFilePath) throws IOException {
	        JsonElement jsonElement = JsonParser.parseReader(new FileReader(jsonFilePath));
	        JsonObject jsonObject = jsonElement.getAsJsonObject();
	        return findDestinationRecursive(jsonObject);
	    }

	    private static String findDestinationRecursive(JsonObject jsonObject) {
	        for (String key : jsonObject.keySet()) {
	            JsonElement element = jsonObject.get(key);

	            if (key.equals("destination")) {
	                return element.getAsString();
	            }

	            if (element.isJsonObject()) {
	                String result = findDestinationRecursive(element.getAsJsonObject());
	                if (result != null) {
	                    return result;
	                }
	            }
	        }
	        return null;
	    }
    }

